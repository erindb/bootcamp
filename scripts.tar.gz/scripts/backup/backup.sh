#!/bin/bash
today=$(date +%F)
tobackup=./to_backup
server=your-SUNet-ID@corn.stanford.edu
tar czf - $tobackup | ssh $server '( cd Documents/backup_files/ ; cat > '${today}'.tar.gz )'
