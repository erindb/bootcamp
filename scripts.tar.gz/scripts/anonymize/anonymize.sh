#!/bin/bash
mkdir ../anonymized_data/
i=0
for f in data_subject_*.json
do
	cp $f ../anonymized_data/data_subject_${i}.json 
	i=$((i+1))
done
