#!/bin/bash
these_files=(${1}/*.tsv)
if [ ! -e "${these_files[0]}" ] 
then
    echo Exiting, no .tsv files found in $1
    exit 1
fi 
for f in ${1}/*.tsv
do
    sed s/\\t/,/g $f > ${f%.tsv}.csv
done
